interface Window {
    Tawk_API: any;
  }